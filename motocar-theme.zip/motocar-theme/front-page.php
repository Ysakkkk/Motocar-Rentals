﻿<!DOCTYPE html>
<html <?php language_attributes(); ?>>
<head>
    <meta charset="<?php bloginfo('charset'); ?>">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta name="description" content="MotoCar Rentals - Alquila la emoción, vive la experiencia. Alquiler de carros y motos en Antioquia, Colombia.">
    <?php wp_head(); ?>
</head>
<body <?php body_class(); ?>>
<?php wp_body_open(); ?>

<!-- ==========================================
     TOP BAR - INFORMACIÓN DE EMPRESA
     ========================================== -->
<div class="mc-topbar">
    <div class="mc-container">
        <div class="mc-topbar__inner">
            <div class="mc-topbar__info">
                <a href="https://maps.google.com/?q=Aeropuerto+Jose+Maria+Cordova" target="_blank" class="mc-topbar__item">
                    <i class="fas fa-map-marker-alt"></i>
                    <span>Aeropuerto José María Córdova</span>
                </a>
                <a href="mailto:motocarrentals@gmail.com" class="mc-topbar__item">
                    <i class="fas fa-envelope"></i>
                    <span>motocarrentals@gmail.com</span>
                </a>
            </div>
            <div class="mc-topbar__right">
                <div class="mc-topbar__social">
                    <a href="https://www.facebook.com/p/MotoCar-Rentals-61558707917054/" target="_blank" aria-label="Facebook"><i class="fab fa-facebook-f"></i></a>
                    <a href="https://wa.me/573202161156" target="_blank" aria-label="WhatsApp"><i class="fab fa-whatsapp"></i></a>
                    <a href="https://www.instagram.com/motocar_rentals/" target="_blank" aria-label="Instagram"><i class="fab fa-instagram"></i></a>
                    <a href="https://www.tiktok.com/@motocar.rentals" target="_blank" aria-label="TikTok"><i class="fab fa-tiktok"></i></a>
                </div>
                <div class="mc-topbar__lang">
                    <span class="mc-topbar__lang-label" data-i18n="lang_label">Idioma</span>
                    <button class="mc-lang-btn active" data-lang="es" title="Español">
                        <img src="<?php echo get_template_directory_uri(); ?>/assets/img/flag-es.png" alt="Español">
                    </button>
                    <button class="mc-lang-btn" data-lang="en" title="English">
                        <img src="<?php echo get_template_directory_uri(); ?>/assets/img/flag-en.png" alt="English">
                    </button>
                </div>
            </div>
        </div>
    </div>
</div>

<!-- ==========================================
     HEADER / NAVEGACIÓN
     ========================================== -->
<header class="mc-header" id="header">
    <div class="mc-container">
        <div class="mc-header__inner">
            <a href="<?php echo home_url(); ?>" class="mc-header__logo">
                <?php if (has_custom_logo()) : ?>
                    <?php the_custom_logo(); ?>
                <?php else : ?>
                    <img src="<?php echo get_template_directory_uri(); ?>/assets/img/logo.png" alt="MotoCar Rentals" class="mc-logo-img">
                <?php endif; ?>
            </a>

            <nav class="mc-nav" id="mainNav">
                <ul class="mc-nav__list">
                    <li><a href="#inicio" class="mc-nav__link active" data-i18n="nav_inicio">Inicio</a></li>
                    <li><a href="#vehiculos" class="mc-nav__link" data-i18n="nav_vehiculos">Vehículos</a></li>
                    <li><a href="#lugares" class="mc-nav__link" data-i18n="nav_lugares">Lugares de Interés</a></li>
                    <li><a href="#nosotros" class="mc-nav__link" data-i18n="nav_nosotros">Nosotros</a></li>
                    <li><a href="#quienes-somos" class="mc-nav__link" data-i18n="nav_quienes">Quiénes Somos</a></li>
                </ul>
            </nav>

            <button class="mc-header__toggle" id="menuToggle" aria-label="Abrir menú">
                <span></span>
                <span></span>
                <span></span>
            </button>
        </div>
    </div>
</header>

<!-- ==========================================
     HERO SLIDER / GALERÍA
     ========================================== -->
<section class="mc-hero" id="inicio">
    <div class="mc-hero__slider" id="heroSlider">
        <div class="mc-hero__slide active" style="background-image: url('<?php echo get_template_directory_uri(); ?>/assets/img/slide-1.webp');"></div>
        <div class="mc-hero__slide" style="background-image: url('<?php echo get_template_directory_uri(); ?>/assets/img/slide-2.jpeg');"></div>
        <div class="mc-hero__slide" style="background-image: url('<?php echo get_template_directory_uri(); ?>/assets/img/slide-3.jpg');"></div>
        <div class="mc-hero__slide" style="background-image: url('<?php echo get_template_directory_uri(); ?>/assets/img/slide-4.jpeg');"></div>
    </div>
    <div class="mc-hero__overlay"></div>
    <div class="mc-hero__content">
        <h1 class="mc-hero__title" data-i18n-html="hero_title">
            ¡Alquila la emoción,<br>
            vive la experiencia!
        </h1>
    </div>
    <div class="mc-hero__dots" id="heroDots">
        <button class="mc-hero__dot active" data-slide="0"></button>
        <button class="mc-hero__dot" data-slide="1"></button>
        <button class="mc-hero__dot" data-slide="2"></button>
        <button class="mc-hero__dot" data-slide="3"></button>
    </div>
</section>

<!-- ==========================================
     BUSCADOR / FILTRO
     ========================================== -->
<section class="mc-search">
    <div class="mc-container">
        <div class="mc-search__box">
            <form class="mc-search__form" id="filterForm">
                <div class="mc-search__group">
                    <label class="mc-search__label" data-i18n="search_tipo">Tipo</label>
                    <div class="mc-toggle" id="tipoToggle">
                        <button type="button" class="mc-toggle__btn active" data-value="carro" data-i18n="search_carro">Carro</button>
                        <button type="button" class="mc-toggle__btn" data-value="moto" data-i18n="search_moto">Moto</button>
                    </div>
                    <input type="hidden" name="tipo" id="filterTipo" value="carro">
                </div>
                <div class="mc-search__group">
                    <label class="mc-search__label" data-i18n="search_precio">Precio</label>
                    <select name="precio_rango" id="filterPrecio">
                        <option value="" data-i18n="search_all_prices">Todos los precios</option>
                        <option value="0-80000" data-i18n="search_hasta_80">Hasta $80.000</option>
                        <option value="80000-120000" data-i18n="search_80_120">$80.000 - $120.000</option>
                        <option value="120000-200000" data-i18n="search_120_200">$120.000 - $200.000</option>
                        <option value="200000-999999" data-i18n="search_mas_200">Más de $200.000</option>
                    </select>
                </div>
                <div class="mc-search__group mc-search__group--disponibilidad">
                    <label class="mc-search__label" data-i18n="search_disponibilidad">Disponibilidad</label>
                    <input type="text" id="filterFechas" name="fechas" placeholder="Seleccionar fechas" data-i18n-placeholder="search_fechas_placeholder" readonly>
                    <input type="hidden" id="filterFechaInicio" name="fecha_inicio">
                    <input type="hidden" id="filterFechaFin" name="fecha_fin">
                </div>
                <div class="mc-search__group mc-search__group--btn">
                    <button type="submit" class="mc-btn mc-btn--primary mc-btn--filter" id="filterBtn" data-i18n="search_filtrar">
                        Filtrar
                    </button>
                </div>
            </form>
        </div>
    </div>
</section>

<!-- ==========================================
     CATÁLOGO DE VEHÍCULOS
     ========================================== -->
<section class="mc-catalogo" id="vehiculos">
    <div class="mc-container">
        <div class="mc-section-header">
            <h2 class="mc-section-title mc-section-title--script" data-i18n="catalog_title">Conoce nuestros vehículos</h2>
            <p class="mc-section-subtitle" data-i18n="catalog_subtitle">Nuestra flota diversa incluye sedanes, SUV y camionetas, todos sometidos a rigurosas inspecciones y mantenimientos por profesionales, garantizando así los más altos estándares de calidad. Te invitamos a realizar tu reserva hoy mismo a través de nuestro sistema de reservas en línea.</p>
        </div>

        <div class="mc-catalogo__grid" id="vehiculosGrid">
            <?php
            $vehicles = new WP_Query(array(
                'post_type'      => 'vehiculo',
                'posts_per_page' => -1,
                'post_status'    => 'publish',
                'meta_key'       => '_precio_dia',
                'orderby'        => 'meta_value_num',
                'order'          => 'ASC',
            ));

            // Sort by subcategory hierarchy then price
            $subcat_order = array('moto' => 1, 'hatchback' => 2, 'sedan' => 3, 'camioneta' => 4);
            $sorted_posts = array();
            if ($vehicles->have_posts()) {
                while ($vehicles->have_posts()) {
                    $vehicles->the_post();
                    $sorted_posts[] = array(
                        'post'  => get_post(),
                        'subcat' => get_post_meta(get_the_ID(), '_subcategoria', true),
                        'precio' => (int) get_post_meta(get_the_ID(), '_precio_dia', true),
                    );
                }
                wp_reset_postdata();
                usort($sorted_posts, function($a, $b) use ($subcat_order) {
                    $oa = $subcat_order[$a['subcat']] ?? 99;
                    $ob = $subcat_order[$b['subcat']] ?? 99;
                    if ($oa !== $ob) return $oa - $ob;
                    return $a['precio'] - $b['precio'];
                });
            }

            if (!empty($sorted_posts)) :
                foreach ($sorted_posts as $item) :
                    setup_postdata($item['post']);
                    $id = $item['post']->ID;
                    $precio_dia = get_post_meta($id, '_precio_dia', true);
                    $modelo = get_post_meta($id, '_modelo', true);
                    $ano = get_post_meta($id, '_ano', true);
                    $transmision = get_post_meta($id, '_transmision', true);
                    $pasajeros = get_post_meta($id, '_pasajeros', true);
                    $cilindrada = get_post_meta($id, '_cilindrada', true);
                    $aire = get_post_meta($id, '_aire_acondicionado', true);
                    $subcategoria = get_post_meta($id, '_subcategoria', true);
                    $tipos = wp_get_post_terms($id, 'tipo_vehiculo', array('fields' => 'slugs'));
                    $tipo_class = !empty($tipos) ? $tipos[0] : '';
                    $thumbnail = get_the_post_thumbnail_url($id, 'medium');
                    $precio_usd = $precio_dia ? number_format($precio_dia / 3690, 2, ',', '.') : '0';
                    $es_moto = ($tipo_class === 'moto');
            ?>
                <div class="mc-card" data-vehicle-id="<?php echo $id; ?>" data-tipo="<?php echo esc_attr($tipo_class); ?>" data-subcategoria="<?php echo esc_attr($subcategoria); ?>" data-precio="<?php echo esc_attr($precio_dia); ?>">
                    <span class="mc-card__badge"><?php echo esc_html($pasajeros ?: '5'); ?> Personas</span>
                    <h3 class="mc-card__title"><?php the_title(); ?></h3>
                    <div class="mc-card__image">
                        <?php if ($thumbnail) : ?>
                            <img src="<?php echo esc_url($thumbnail); ?>" alt="<?php the_title(); ?>" loading="lazy">
                        <?php else : ?>
                            <img src="<?php echo get_template_directory_uri(); ?>/assets/img/placeholder.jpg" alt="<?php the_title(); ?>" loading="lazy">
                        <?php endif; ?>
                    </div>
                    <div class="mc-card__pricing">
                        <?php if ($precio_dia) : ?>
                            <span class="mc-card__price">Desde $<?php echo number_format($precio_dia, 0, ',', '.'); ?> <small>COP/día</small></span>
                            <span class="mc-card__price-usd">$<?php echo $precio_usd; ?> <small>USD/día</small></span>
                        <?php endif; ?>
                    </div>
                    <div class="mc-card__specs">
                        <div class="mc-card__spec">
                            <span class="mc-card__spec-label">Motor</span>
                            <span class="mc-card__spec-value"><?php echo esc_html($cilindrada ?: '2000 cc'); ?></span>
                        </div>
                        <div class="mc-card__spec">
                            <span class="mc-card__spec-label">Caja</span>
                            <span class="mc-card__spec-value"><?php echo ucfirst(esc_html($transmision ?: 'Mecánica')); ?></span>
                        </div>
                        <div class="mc-card__spec">
                            <span class="mc-card__spec-label"><?php echo $es_moto ? 'ABS' : 'Aire'; ?></span>
                            <span class="mc-card__spec-value"><?php echo $es_moto ? 'Sí' : 'acondicionado'; ?></span>
                        </div>
                    </div>
                    <button class="mc-btn mc-btn--primary mc-btn--card" onclick="openVehicleModal(<?php echo $id; ?>)">
                        Reserva Ahora
                    </button>
                </div>
            <?php
                endforeach;
                wp_reset_postdata();
            else :
            ?>
                <!-- VEHÍCULOS DE DEMO (orden: Motos, Hatchbacks, Sedan, Camionetas — por precio) -->
                <div class="mc-card" data-vehicle-id="demo-5" data-tipo="moto" data-subcategoria="moto" data-precio="55000">
                    <span class="mc-card__badge">2 Personas</span>
                    <h3 class="mc-card__title">Yamaha Aerox</h3>
                    <div class="mc-card__image">
                        <img src="<?php echo get_template_directory_uri(); ?>/assets/img/aerox.png" alt="Yamaha Aerox" loading="lazy">
                    </div>
                    <div class="mc-card__pricing">
                        <span class="mc-card__price">Desde $80.000 <small>COP/día</small></span>
                        <span class="mc-card__price-usd">$21,70 <small>USD/día</small></span>
                    </div>
                    <div class="mc-card__specs">
                        <div class="mc-card__spec"><span class="mc-card__spec-label">Motor</span><span class="mc-card__spec-value">155 cc</span></div>
                        <div class="mc-card__spec"><span class="mc-card__spec-label">Caja</span><span class="mc-card__spec-value">Automática</span></div>
                        <div class="mc-card__spec"><span class="mc-card__spec-label">ABS</span><span class="mc-card__spec-value">Sí</span></div>
                    </div>
                    <button class="mc-btn mc-btn--primary mc-btn--card" onclick="openVehicleModalDemo('Yamaha Aerox', '2024', 'Automática', '2', 'Gasolina', 'No', '155 cc', '80000', '<?php echo get_template_directory_uri(); ?>/assets/img/aerox.png', 'La Yamaha Aerox 155 es un scooter deportivo, ágil y moderno.')">
                        Reserva Ahora
                    </button>
                </div>

                <div class="mc-card" data-vehicle-id="demo-4" data-tipo="moto" data-subcategoria="moto" data-precio="75000">
                    <span class="mc-card__badge">2 Personas</span>
                    <h3 class="mc-card__title">Fz - 250</h3>
                    <div class="mc-card__image">
                        <img src="<?php echo get_template_directory_uri(); ?>/assets/img/fz250.png" alt="FZ-250" loading="lazy">
                    </div>
                    <div class="mc-card__pricing">
                        <span class="mc-card__price">Desde $100.000 <small>COP/día</small></span>
                        <span class="mc-card__price-usd">$27,10 <small>USD/día</small></span>
                    </div>
                    <div class="mc-card__specs">
                        <div class="mc-card__spec"><span class="mc-card__spec-label">Motor</span><span class="mc-card__spec-value">250 cc</span></div>
                        <div class="mc-card__spec"><span class="mc-card__spec-label">Caja</span><span class="mc-card__spec-value">Mecánica</span></div>
                        <div class="mc-card__spec"><span class="mc-card__spec-label">ABS</span><span class="mc-card__spec-value">Sí</span></div>
                    </div>
                    <button class="mc-btn mc-btn--primary mc-btn--card" onclick="openVehicleModalDemo('Yamaha FZ-250', '2024', 'Manual', '2', 'Gasolina', 'No', '250 cc', '100000', '<?php echo get_template_directory_uri(); ?>/assets/img/fz250.png', 'La Yamaha FZ-250 es una moto deportiva con excelente rendimiento.')">
                        Reserva Ahora
                    </button>
                </div>

                <div class="mc-card" data-vehicle-id="demo-3" data-tipo="carro" data-subcategoria="sedan" data-precio="95000">
                    <span class="mc-card__badge">5 Personas</span>
                    <h3 class="mc-card__title">Renault Logan</h3>
                    <div class="mc-card__image">
                        <img src="<?php echo get_template_directory_uri(); ?>/assets/img/renault-logan.png" alt="Renault Logan" loading="lazy">
                    </div>
                    <div class="mc-card__pricing">
                        <span class="mc-card__price">Desde $200.000 <small>COP/día</small></span>
                        <span class="mc-card__price-usd">$54,20 <small>USD/día</small></span>
                    </div>
                    <div class="mc-card__specs">
                        <div class="mc-card__spec"><span class="mc-card__spec-label">Motor</span><span class="mc-card__spec-value">1600 cc</span></div>
                        <div class="mc-card__spec"><span class="mc-card__spec-label">Caja</span><span class="mc-card__spec-value">Mecánica</span></div>
                        <div class="mc-card__spec"><span class="mc-card__spec-label">Aire</span><span class="mc-card__spec-value">acondicionado</span></div>
                    </div>
                    <button class="mc-btn mc-btn--primary mc-btn--card" onclick="openVehicleModalDemo('Renault Logan', '2024', 'Manual', '5', 'Gasolina', 'Sí', '1600 cc', '200000', '<?php echo get_template_directory_uri(); ?>/assets/img/renault-logan.png', 'El Renault Logan es un sedán confiable y económico.')">
                        Reserva Ahora
                    </button>
                </div>

                <div class="mc-card" data-vehicle-id="demo-2" data-tipo="carro" data-subcategoria="sedan" data-precio="135000">
                    <span class="mc-card__badge">5 Personas</span>
                    <h3 class="mc-card__title">Volkswagen</h3>
                    <div class="mc-card__image">
                        <img src="<?php echo get_template_directory_uri(); ?>/assets/img/volkswagen.png" alt="Volkswagen" loading="lazy">
                    </div>
                    <div class="mc-card__pricing">
                        <span class="mc-card__price">Desde $200.000 <small>COP/día</small></span>
                        <span class="mc-card__price-usd">$54,20 <small>USD/día</small></span>
                    </div>
                    <div class="mc-card__specs">
                        <div class="mc-card__spec"><span class="mc-card__spec-label">Motor</span><span class="mc-card__spec-value">2000 cc</span></div>
                        <div class="mc-card__spec"><span class="mc-card__spec-label">Caja</span><span class="mc-card__spec-value">Mecánica</span></div>
                        <div class="mc-card__spec"><span class="mc-card__spec-label">Aire</span><span class="mc-card__spec-value">acondicionado</span></div>
                    </div>
                    <button class="mc-btn mc-btn--primary mc-btn--card" onclick="openVehicleModalDemo('Volkswagen', '2024', 'Manual', '5', 'Gasolina', 'Sí', '2000 cc', '200000', '<?php echo get_template_directory_uri(); ?>/assets/img/volkswagen.png', 'El Volkswagen ofrece confort, seguridad y eficiencia.')">
                        Reserva Ahora
                    </button>
                </div>

                <div class="mc-card" data-vehicle-id="demo-1" data-tipo="carro" data-subcategoria="camioneta" data-precio="135000">
                    <span class="mc-card__badge">5 Personas</span>
                    <h3 class="mc-card__title">Kia Sportage</h3>
                    <div class="mc-card__image">
                        <img src="<?php echo get_template_directory_uri(); ?>/assets/img/kia-sportage.png" alt="Kia Sportage" loading="lazy">
                    </div>
                    <div class="mc-card__pricing">
                        <span class="mc-card__price">Desde $200.000 <small>COP/día</small></span>
                        <span class="mc-card__price-usd">$54,20 <small>USD/día</small></span>
                    </div>
                    <div class="mc-card__specs">
                        <div class="mc-card__spec"><span class="mc-card__spec-label">Motor</span><span class="mc-card__spec-value">2000 cc</span></div>
                        <div class="mc-card__spec"><span class="mc-card__spec-label">Caja</span><span class="mc-card__spec-value">Mecánica</span></div>
                        <div class="mc-card__spec"><span class="mc-card__spec-label">Aire</span><span class="mc-card__spec-value">acondicionado</span></div>
                    </div>
                    <button class="mc-btn mc-btn--primary mc-btn--card" onclick="openVehicleModalDemo('Kia Sportage', '2025', 'Automática', '5', 'Gasolina', 'Sí', '2000 cc', '200000', '<?php echo get_template_directory_uri(); ?>/assets/img/kia-sportage.png', 'La Kia Sportage es una SUV que combina diseño moderno, buen espacio interior y tecnología.')">
                        Reserva Ahora
                    </button>
                </div>
            <?php endif; ?>
        </div>
    </div>
</section>

<!-- ==========================================
     RESEÑAS DE GOOGLE
     ========================================== -->
<section class="mc-reviews" id="resenas">
    <div class="mc-container">
        <div class="mc-section-header">
            <h2 class="mc-section-title mc-section-title--script" data-i18n="reviews_title">Lo que dicen nuestros clientes</h2>
            <p class="mc-section-subtitle" data-i18n="reviews_subtitle">Reseñas verificadas de Google</p>
        </div>
        <div class="mc-reviews__content">
            <?php
            // Pega aquí el shortcode del plugin de Google Reviews.
            // Ejemplo: echo do_shortcode('[google-reviews]');
            // Plugins recomendados: "Jetstagram" o "Widgets for Google Reviews"
            ?>
            <!-- Shortcode de Google Reviews va aquí -->
        </div>
    </div>
</section>

<!-- ==========================================
     RINCONES ÚNICOS DE ANTIOQUIA
     ========================================== -->
<section class="mc-lugares" id="lugares">
    <div class="mc-container">
        <div class="mc-section-header">
            <h2 class="mc-section-title mc-section-title--script" data-i18n-html="lugares_title">Rincones Únicos de<br>Antioquia</h2>
        </div>
        <div class="mc-lugares__slider">
            <button class="mc-lugares__arrow mc-lugares__arrow--left" id="lugarPrev" aria-label="Anterior">
                <i class="fas fa-chevron-left"></i>
            </button>

            <div class="mc-lugares__slides" id="lugaresSlides">
                <div class="mc-lugares__slide active">
                    <div class="mc-lugares__card">
                        <div class="mc-lugares__image" style="grid-column: 1 / -1;">
                            <img src="<?php echo get_template_directory_uri(); ?>/assets/img/santa-fe.jpg" alt="Santa Fé de Antioquia">
                        </div>
                        <div class="mc-lugares__info">
                            <h3 class="mc-lugares__name">Santa Fé de<br>Antioquia</h3>
                            <div class="mc-lugares__text">
                                <p data-i18n="lugar_santa_fe">Santa Fe de Antioquia es un encantador pueblo colonial, Monumento Nacional, famoso por sus calles empedradas, arquitectura conservada (siglos XVI-XVIII) y su cálido clima, ofreciendo un viaje al pasado con iglesias históricas, el emblemático Puente de Occidente, plazas coloniales y tradiciones como el tamarindo y la filigrana, ideal para disfrutar de cultura, historia y naturaleza cercana.</p>
                            </div>
                        </div>
                    </div>
                </div>
                <div class="mc-lugares__slide">
                    <div class="mc-lugares__card">
                        <div class="mc-lugares__image" style="grid-column: 1 / -1;">
                            <img src="<?php echo get_template_directory_uri(); ?>/assets/img/guatape.jpg" alt="Guatapé">
                        </div>
                        <div class="mc-lugares__info">
                            <h3 class="mc-lugares__name">Guatapé</h3>
                            <div class="mc-lugares__text">
                                <p data-i18n="lugar_guatape">Guatapé es famoso por la Piedra del Peñol, sus coloridas fachadas de zócalos y el embalse con vistas espectaculares. Ideal para deportes acuáticos, senderismo y disfrutar de la naturaleza.</p>
                            </div>
                        </div>
                    </div>
                </div>
                <div class="mc-lugares__slide">
                    <div class="mc-lugares__card">
                        <div class="mc-lugares__image" style="grid-column: 1 / -1;">
                            <img src="<?php echo get_template_directory_uri(); ?>/assets/img/jardin.jpg" alt="Jardín">
                        </div>
                        <div class="mc-lugares__info">
                            <h3 class="mc-lugares__name">Jardín</h3>
                            <div class="mc-lugares__text">
                                <p data-i18n="lugar_jardin">Jardín es un pueblo patrimonio de Colombia, rodeado de montañas verdes, cascadas y fincas cafeteras. Su parque principal, la Basílica Menor y la Cueva del Esplendor lo hacen un lugar mágico.</p>
                            </div>
                        </div>
                    </div>
                </div>
                <div class="mc-lugares__slide">
                    <div class="mc-lugares__card">
                        <div class="mc-lugares__image" style="grid-column: 1 / -1;">
                            <img src="<?php echo get_template_directory_uri(); ?>/assets/img/jerico.jpg" alt="Jericó">
                        </div>
                        <div class="mc-lugares__info">
                            <h3 class="mc-lugares__name">Jericó</h3>
                            <div class="mc-lugares__text">
                                <p data-i18n="lugar_jerico">Jericó es la cuna de la Santa Laura Montoya, un pueblo de calles empinadas, balcones coloniales y paisajes cafeteros. Su riqueza cultural y miradores naturales lo hacen imperdible.</p>
                            </div>
                        </div>
                    </div>
                </div>
            </div>

            <button class="mc-lugares__arrow mc-lugares__arrow--right" id="lugarNext" aria-label="Siguiente">
                <i class="fas fa-chevron-right"></i>
            </button>
        </div>

        <div class="mc-lugares__dots" id="lugaresDots">
            <button class="mc-lugares__dot active" data-slide="0"></button>
            <button class="mc-lugares__dot" data-slide="1"></button>
            <button class="mc-lugares__dot" data-slide="2"></button>
            <button class="mc-lugares__dot" data-slide="3"></button>
        </div>
    </div>
</section>

<!-- ==========================================
     CONÓCENOS / SERVICIOS
     ========================================== -->
<section class="mc-about" id="nosotros">
    <div class="mc-container">
        <div class="mc-about__grid">
            <!-- Columna izquierda - Instagram Embed -->
            <div class="mc-about__cta">
                <div class="mc-about__instagram">
                    <?php
                    // Pega aquí el shortcode del plugin de Instagram.
                    // Ejemplo: echo do_shortcode('[instagram-feed feed=1]');
                    // Plugin recomendado: "Smash Balloon Instagram Feed"
                    ?>
                    <!-- Shortcode de Instagram va aquí -->
                </div>
            </div>

            <!-- Columna derecha - Servicios -->
            <div class="mc-about__services">
                <h2 class="mc-section-title" data-i18n="about_title">Conócenos</h2>
                <div class="mc-services__list">
                    <div class="mc-service">
                        <div class="mc-service__icon">
                            <i class="fas fa-headset"></i>
                        </div>
                        <div class="mc-service__content">
                            <h4 data-i18n="srv_atencion_title">Atención personalizada</h4>
                            <p data-i18n="srv_atencion_desc">Te brindamos un servicio directo y personalizado para que tu experiencia sea única.</p>
                        </div>
                    </div>

                    <div class="mc-service">
                        <div class="mc-service__icon">
                            <i class="fas fa-clock"></i>
                        </div>
                        <div class="mc-service__content">
                            <h4 data-i18n="srv_247_title">Disponibilidad 24/7</h4>
                            <p data-i18n="srv_247_desc">Estamos disponibles las 24 horas, los 7 días de la semana para ti.</p>
                        </div>
                    </div>

                    <div class="mc-service">
                        <div class="mc-service__icon">
                            <i class="fas fa-truck"></i>
                        </div>
                        <div class="mc-service__content">
                            <h4 data-i18n="srv_domicilio_title">Servicio a domicilio</h4>
                            <p data-i18n="srv_domicilio_desc">Llevamos y recogemos el vehículo donde lo necesites sin costo adicional.</p>
                        </div>
                    </div>

                    <div class="mc-service">
                        <div class="mc-service__icon">
                            <i class="fas fa-user-tie"></i>
                        </div>
                        <div class="mc-service__content">
                            <h4 data-i18n="srv_conductor_title">Conductor elegido</h4>
                            <p data-i18n="srv_conductor_desc">Si prefieres, te asignamos un conductor profesional para tu viaje.</p>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>

<!-- ==========================================
     PREGUNTAS FRECUENTES (FAQ)
     ========================================== -->
    <div class="mc-faq" id="faq">
        <div class="mc-container">
            <button class="mc-faq__toggle" id="faqToggle" aria-expanded="false">
                <div class="mc-faq__toggle-text">
                    <h2 class="mc-section-title mc-section-title--script" data-i18n="faq_title">Preguntas Frecuentes</h2>
                    <p class="mc-section-subtitle" data-i18n="faq_subtitle">Resuelve tus dudas antes de reservar</p>
                </div>
                <div class="mc-faq__toggle-icon">
                    <i class="fas fa-plus"></i>
                </div>
            </button>

        <div class="mc-faq__list" id="faqList">
            <div class="mc-faq__item">
                <button class="mc-faq__question" aria-expanded="false">
                    <span data-i18n="faq_q1">¿Cuáles son los procedimientos que debo seguir en el caso de accidente?</span>
                    <i class="fas fa-chevron-down mc-faq__icon"></i>
                </button>
                <div class="mc-faq__answer" data-i18n-html="faq_a1">
                    <p>En caso de un accidente con el auto o motocicleta alquilado, es crucial informar el incidente de inmediato a MotoCar Rentals llamando al número <strong>+57 3202161156</strong>.</p>
                    <p>Se debe registrar el reporte de la ocurrencia en el organismo correspondiente y presentarlo en un plazo máximo de 48 horas en una agencia de MotoCar Rentals. Además, es necesario completar el Aviso de Reporte de Siniestro en nuestra agencia.</p>
                </div>
            </div>

            <div class="mc-faq__item">
                <button class="mc-faq__question" aria-expanded="false">
                    <span data-i18n="faq_q2">¿Qué pasa si se genera una foto multa mientras rento un vehículo con MotoCar Rentals?</span>
                    <i class="fas fa-chevron-down mc-faq__icon"></i>
                </button>
                <div class="mc-faq__answer" data-i18n-html="faq_a2">
                    <p>Si durante tu renta se generó una fotomulta, puedes consultar la evidencia en la página web del organismo de tránsito donde ocurrió la infracción. Para aprovechar los descuentos disponibles, debes hacer el cambio de contraventor dentro del tiempo estipulado, tomar el curso de sensibilización (si aplica) y realizar el pago a través del SIMIT o directamente en el organismo de tránsito donde se emitió la fotomulta.</p>
                    <p>Cuando MotoCar Rentals sea notificado, te enviaremos un correo con los documentos necesarios para hacer el cambio de contraventor. Si sabes que cometiste una infracción y no recibes el aviso, escríbenos a <strong>motocarrentals@gmail.com</strong> y te enviaremos la información.</p>
                    <p>Si el pago no se realiza dentro del plazo, MotoCar Rentals SAS lo cobrará automáticamente a la tarjeta de crédito registrada en tu contrato. Por favor, mantén activa tu tarjeta. De lo contrario, no podrás volver a utilizar el servicio hasta que realices el pago.</p>
                </div>
            </div>

            <div class="mc-faq__item">
                <button class="mc-faq__question" aria-expanded="false">
                    <span data-i18n="faq_q3">¿Cuáles son los procedimientos a seguir en el caso de hurto o robo del auto o motocicleta?</span>
                    <i class="fas fa-chevron-down mc-faq__icon"></i>
                </button>
                <div class="mc-faq__answer" data-i18n-html="faq_a3">
                    <p>Notificar de inmediato a las autoridades a través de los canales designados y presentar una denuncia ante la Fiscalía en caso de un incidente. Debes ampliar la denuncia a MotoCar Rentals al número <strong>+57 3202161156</strong> y enviar los documentos de respaldo a la agencia donde retiraste el vehículo en un plazo de cuarenta y ocho (48) horas desde el suceso.</p>
                    <p>La falta de cumplimiento de este procedimiento podría resultar en la pérdida de las coberturas contratadas. Además, se requiere entregar las constancias necesarias de la Fiscalía en casos de hurto.</p>
                </div>
            </div>

            <div class="mc-faq__item">
                <button class="mc-faq__question" aria-expanded="false">
                    <span data-i18n="faq_q4">¿Qué es necesario para alquilar un vehículo o motocicleta?</span>
                    <i class="fas fa-chevron-down mc-faq__icon"></i>
                </button>
                <div class="mc-faq__answer" data-i18n-html="faq_a4">
                    <ul>
                        <li><strong>Licencia de Conducir Válida:</strong> Es necesario presentar una licencia de conducir válida y en vigencia al momento de realizar el alquiler. Asegúrate de que tu licencia esté en buen estado y cumpla con los requisitos colombianos.</li>
                        <li><strong>Tarjeta de Crédito:</strong> Se requiere una tarjeta de crédito a nombre del titular de la reserva para cubrir el depósito de seguridad. La tarjeta debe tener suficiente límite de crédito para cubrir posibles cargos adicionales. No se acepta otro método para el pago del carro.</li>
                        <li><strong>Edad Mínima:</strong> Debes cumplir con la edad mínima requerida para alquilar un vehículo, en Colombia es 18 años.</li>
                    </ul>
                </div>
            </div>

            <div class="mc-faq__item">
                <button class="mc-faq__question" aria-expanded="false">
                    <span data-i18n="faq_q5">¿El responsable por el alquiler del auto puede pasar la conducción a otra persona?</span>
                    <i class="fas fa-chevron-down mc-faq__icon"></i>
                </button>
                <div class="mc-faq__answer" data-i18n-html="faq_a5">
                    <p>Sí. En el momento de la apertura del contrato de alquiler del vehículo, el cliente puede autorizar por un valor extra el número de personas que desee para conducir el auto alquilado, desde que estos conductores obedezcan a los requisitos mínimos establecidos por MotoCar Rentals.</p>
                    <p>Te invitamos a revisar las condiciones detalladas al momento de hacer tu reserva o contactarnos para obtener información específica sobre tus necesidades de alquiler.</p>
                </div>
            </div>

            <div class="mc-faq__item">
                <button class="mc-faq__question" aria-expanded="false">
                    <span data-i18n="faq_q6">¿Es necesario pagar por el combustible utilizado en el alquiler de un auto?</span>
                    <i class="fas fa-chevron-down mc-faq__icon"></i>
                </button>
                <div class="mc-faq__answer" data-i18n-html="faq_a6">
                    <p>El vehículo o la motocicleta se entregará con el tanque lleno, se debe devolver en el mismo nivel, de lo contrario se hará un cobro por el combustible faltante al momento de la devolución del vehículo.</p>
                </div>
            </div>

            <div class="mc-faq__item">
                <button class="mc-faq__question" aria-expanded="false">
                    <span data-i18n="faq_q7">¿Cómo se hace la reserva para alquilar un auto o una moto?</span>
                    <i class="fas fa-chevron-down mc-faq__icon"></i>
                </button>
                <div class="mc-faq__answer" data-i18n-html="faq_a7">
                    <p>Se recomienda realizar una reserva previa a través de nuestro sitio web <strong>motocarrentals.com.co</strong> o a través de nuestro centro de Reservas MotoCar vía WhatsApp <strong>+57 3202161156</strong>.</p>
                </div>
            </div>

            <div class="mc-faq__item">
                <button class="mc-faq__question" aria-expanded="false">
                    <span data-i18n="faq_q8">¿Qué es el Pico y Placa en Medellín?</span>
                    <i class="fas fa-chevron-down mc-faq__icon"></i>
                </button>
                <div class="mc-faq__answer" data-i18n-html="faq_a8">
                    <p>El Pico y Placa es una medida de restricción de circulación que se aplica a carros y motocicletas en el área metropolitana del Valle de Aburrá. Aplica en los municipios de Medellín, Bello, Envigado, Sabaneta, Itagüí, La Estrella, Caldas, Barbosa, Girardota y Copacabana.</p>
                    <p>La restricción se aplica de lunes a viernes, entre las 5:00 a.m. y las 8:00 p.m., y no se aplica en festivos. Las vías exentas, donde se permite circular sin importar la placa, son la Autopista Sur, la Avenida Regional, la Vía Las Palmas, la Avenida 33 y la Transversal de la Montaña.</p>
                    <p>Es importante respetar la restricción, ya que las infracciones conllevan multas y posible inmovilización del vehículo.</p>
                </div>
            </div>

            <div class="mc-faq__item">
                <button class="mc-faq__question" aria-expanded="false">
                    <span data-i18n="faq_q9">¿Es posible alquilar un vehículo o motocicleta con la licencia de conductor extranjera?</span>
                    <i class="fas fa-chevron-down mc-faq__icon"></i>
                </button>
                <div class="mc-faq__answer" data-i18n-html="faq_a9">
                    <p>Si eres extranjero, se requiere documentación adicional como pasaporte, identificación oficial u otros documentos. Los colombianos residentes en el exterior deben presentar licencia de conducir colombiana vigente.</p>
                    <p>La excepción se dará en los casos en los que este ciudadano colombiano no haya tenido licencia del país en mención en ningún momento. Para estos casos se deberá tramitar la homologación de la licencia extranjera ante las entidades de tránsito de Colombia.</p>
                </div>
            </div>

            <div class="mc-faq__item">
                <button class="mc-faq__question" aria-expanded="false">
                    <span data-i18n="faq_q10">¿Qué hago para reprogramar o cancelar mi reserva?</span>
                    <i class="fas fa-chevron-down mc-faq__icon"></i>
                </button>
                <div class="mc-faq__answer" data-i18n-html="faq_a10">
                    <p>Puedes comunicarte a nuestra central de reservas vía WhatsApp <strong>+57 320 216 1156</strong>.</p>
                </div>
            </div>

            <div class="mc-faq__item">
                <button class="mc-faq__question" aria-expanded="false">
                    <span data-i18n="faq_q11">¿Qué es cambio de contraventor?</span>
                    <i class="fas fa-chevron-down mc-faq__icon"></i>
                </button>
                <div class="mc-faq__answer" data-i18n-html="faq_a11">
                    <p>Es el trámite que te permite asumir la responsabilidad de una fotomulta generada mientras conducías un vehículo rentado. Es necesario realizar este proceso si quieres acceder a los descuentos ofrecidos por el organismo de tránsito.</p>
                    <p><strong>Importante:</strong> Si la fotomulta fue en Bogotá, no es necesario hacer el cambio de contraventor. Solo debes acercarte con tu documento de identidad y licencia a la Secretaría Distrital de Movilidad o consultar su página web donde fue impuesta la fotomulta para completar el proceso.</p>
                </div>
            </div>

            <div class="mc-faq__item">
                <button class="mc-faq__question" aria-expanded="false">
                    <span data-i18n="faq_q12">¿Cuál es el plazo máximo para la devolución?</span>
                    <i class="fas fa-chevron-down mc-faq__icon"></i>
                </button>
                <div class="mc-faq__answer" data-i18n-html="faq_a12">
                    <p>Asegúrate de devolver el vehículo en la fecha y hora acordadas para evitar cargos adicionales por retrasos. Comunica cualquier cambio en los planes de devolución con antelación a través de la Central de Reservas vía WhatsApp <strong>+57 320 216 1156</strong>.</p>
                </div>
            </div>

            <div class="mc-faq__item">
                <button class="mc-faq__question" aria-expanded="false">
                    <span data-i18n="faq_q13">Si no tengo tarjeta de crédito, ¿alguien puede presentarla por mí en otra ciudad o en otra agencia?</span>
                    <i class="fas fa-chevron-down mc-faq__icon"></i>
                </button>
                <div class="mc-faq__answer" data-i18n-html="faq_a13">
                    <p>El nombre del tarjetahabiente debe verse reflejado en la tarjeta de crédito. Otra persona puede presentar la tarjeta siempre y cuando esté en el momento de la entrega del vehículo.</p>
                </div>
            </div>

            <div class="mc-faq__item">
                <button class="mc-faq__question" aria-expanded="false">
                    <span data-i18n="faq_q14">¿Cuáles son las protecciones ofrecidas en el alquiler?</span>
                    <i class="fas fa-chevron-down mc-faq__icon"></i>
                </button>
                <div class="mc-faq__answer" data-i18n-html="faq_a14">
                    <p>Ofrecemos la cobertura básica obligatoria que ampara el vehículo, con un deducible del 10% según la categoría.</p>
                </div>
            </div>

            <div class="mc-faq__item">
                <button class="mc-faq__question" aria-expanded="false">
                    <span data-i18n="faq_q15">¿Cuáles deben ser las condiciones de devolución del auto o la motocicleta?</span>
                    <i class="fas fa-chevron-down mc-faq__icon"></i>
                </button>
                <div class="mc-faq__answer" data-i18n-html="faq_a15">
                    <p>El auto o la motocicleta debe ser entregado en las mismas condiciones que fue retirado: con el depósito de combustible completo, en estado físico igual al verificado en el check-in de entrega y limpio lo suficiente para conferir el estado de la carrocería.</p>
                    <p>Si el vehículo presenta un faltante de combustible, se procederá con el cobro. Esta tarifa es superior a la de una estación de servicio, ya que incluye otros costos como la movilización, seguros, etc.</p>
                </div>
            </div>

            <div class="mc-faq__item">
                <button class="mc-faq__question" aria-expanded="false">
                    <span data-i18n="faq_q16">Al alquilar un auto o motocicleta, ¿cuáles son los adicionales ofrecidos en MotoCar?</span>
                    <i class="fas fa-chevron-down mc-faq__icon"></i>
                </button>
                <div class="mc-faq__answer" data-i18n-html="faq_a16">
                    <p><strong>Auto:</strong> Silla de bebé, upgrade, devolución en otra ciudad, protección contra terceros, lucro cesante, porta celular y conductor adicional.</p>
                    <p><strong>Motocicleta:</strong> Conductor adicional, upgrade, devolución en otra ciudad, protección contra terceros, lucro cesante, porta celular e impermeables.</p>
                </div>
            </div>

            <div class="mc-faq__item">
                <button class="mc-faq__question" aria-expanded="false">
                    <span data-i18n="faq_q17">¿Qué incluye al rentar una motocicleta en MotoCar?</span>
                    <i class="fas fa-chevron-down mc-faq__icon"></i>
                </button>
                <div class="mc-faq__answer" data-i18n-html="faq_a17">
                    <p>Cuando alquilas una de nuestras motocicletas te incluye dos cascos certificados, dos chalecos reflectivos y los documentos del automotor.</p>
                </div>
            </div>

            <div class="mc-faq__item">
                <button class="mc-faq__question" aria-expanded="false">
                    <span data-i18n="faq_q18">¿Qué requisitos debo cumplir para alquilar un vehículo?</span>
                    <i class="fas fa-chevron-down mc-faq__icon"></i>
                </button>
                <div class="mc-faq__answer" data-i18n-html="faq_a18">
                    <p>Los documentos que solicitamos a la hora de alquilar uno de nuestros vehículos son:</p>
                    <ol>
                        <li>Cédula o Pasaporte (si es Extranjero)</li>
                        <li>Licencia de Conducción (Vigente)</li>
                        <li>Tarjeta de Crédito (Visa-Mastercard) con un cupo mínimo de $1'500.000 COP</li>
                    </ol>
                </div>
            </div>

            <div class="mc-faq__item">
                <button class="mc-faq__question" aria-expanded="false">
                    <span data-i18n="faq_q19">¿Cuáles son las tarifas de alquiler?</span>
                    <i class="fas fa-chevron-down mc-faq__icon"></i>
                </button>
                <div class="mc-faq__answer" data-i18n-html="faq_a19">
                    <p>Las tarifas varían según la temporada y están sujetas a términos y condiciones.</p>
                </div>
            </div>

            <div class="mc-faq__item">
                <button class="mc-faq__question" aria-expanded="false">
                    <span data-i18n="faq_q20">¿Qué se incluye en el precio del alquiler?</span>
                    <i class="fas fa-chevron-down mc-faq__icon"></i>
                </button>
                <div class="mc-faq__answer" data-i18n-html="faq_a20">
                    <p>Tiempo y kilometraje ilimitado, servicio en carretera 24 horas.</p>
                </div>
            </div>

            <div class="mc-faq__item">
                <button class="mc-faq__question" aria-expanded="false">
                    <span data-i18n="faq_q21">¿Qué opciones de seguro hay disponibles?</span>
                    <i class="fas fa-chevron-down mc-faq__icon"></i>
                </button>
                <div class="mc-faq__answer" data-i18n-html="faq_a21">
                    <p>Exoneración de daños al vehículo y exoneración de daños a terceros. Estas exoneraciones están sujetas a términos y condiciones específicos y puede requerir el pago de una tarifa adicional.</p>
                </div>
            </div>

            <div class="mc-faq__item">
                <button class="mc-faq__question" aria-expanded="false">
                    <span data-i18n="faq_q22">¿Cómo puedo reservar un vehículo?</span>
                    <i class="fas fa-chevron-down mc-faq__icon"></i>
                </button>
                <div class="mc-faq__answer" data-i18n-html="faq_a22">
                    <p>Por medio de nuestros canales habilitados:</p>
                    <ul>
                        <li>Página Web</li>
                        <li>Nuestras redes sociales: Instagram, Facebook o vía WhatsApp</li>
                    </ul>
                </div>
            </div>

            <div class="mc-faq__item">
                <button class="mc-faq__question" aria-expanded="false">
                    <span data-i18n="faq_q23">¿Puedo cancelar o modificar mi reserva?</span>
                    <i class="fas fa-chevron-down mc-faq__icon"></i>
                </button>
                <div class="mc-faq__answer" data-i18n-html="faq_a23">
                    <p>Sí, puedes modificar o cancelar con mínimo 24 horas de anticipación sin incurrir en cargos adicionales, siempre y cuando no sea una reservación pre-pagada.</p>
                </div>
            </div>

            <div class="mc-faq__item">
                <button class="mc-faq__question" aria-expanded="false">
                    <span data-i18n="faq_q24">¿Qué debo hacer si tengo un accidente con el vehículo de alquiler?</span>
                    <i class="fas fa-chevron-down mc-faq__icon"></i>
                </button>
                <div class="mc-faq__answer" data-i18n-html="faq_a24">
                    <p>Debe contactarse por medio de nuestros números de atención al cliente o vía WhatsApp indicándonos el incidente para enviar la asistencia vial.</p>
                </div>
            </div>

            <div class="mc-faq__item">
                <button class="mc-faq__question" aria-expanded="false">
                    <span data-i18n="faq_q25">¿Desde qué edad se puede alquilar un vehículo?</span>
                    <i class="fas fa-chevron-down mc-faq__icon"></i>
                </button>
                <div class="mc-faq__answer" data-i18n-html="faq_a25">
                    <p>El alquiler está disponible para conductores mayores de 20 hasta los 75 años.</p>
                </div>
            </div>
        </div>
    </div>
    </div>
</section>

<!-- ==========================================
     QUIÉNES SOMOS
     ========================================== -->
<section class="mc-quienes" id="quienes-somos">
    <div class="mc-container">
        <div class="mc-section-header">
            <h2 class="mc-section-title mc-section-title--script" data-i18n="quienes_title">Quiénes Somos</h2>
            <p class="mc-section-subtitle" data-i18n="quienes_subtitle">Conoce nuestra historia y compromiso</p>
        </div>

        <div class="mc-quienes__intro">
            <p data-i18n-html="quienes_intro1">Desde el <strong>2023</strong>, somos una empresa dedicada al alquiler de vehículos de alta gama, ofreciendo una experiencia única en movilidad y proporcionando una amplia flota que abarca desde motocicletas hasta automóviles Sedan y SUV de última generación.</p>
            <p data-i18n-html="quienes_intro2">Nuestro fin es superar las expectativas de nuestros clientes, ofreciendo no solo vehículos de alto rendimiento, sino también un servicio excepcional. Nos comprometemos a brindar <strong>comodidad, satisfacción y seguridad</strong> en cada trayecto, convirtiendo cada viaje en una experiencia inolvidable.</p>
            <p data-i18n="quienes_intro3">Nuestro equipo altamente capacitado está disponible para asesorarte en la elección del vehículo perfecto según tus necesidades y preferencias. Además, estamos comprometidos a brindar un servicio personalizado que se adapte a tus expectativas y supere tus requerimientos.</p>
            <p data-i18n="quienes_intro4">La excelencia es nuestro estándar, y trabajamos incansablemente para garantizar que cada detalle, desde la reserva hasta la devolución del vehículo, se lleve a cabo de manera impecable.</p>
            <p class="mc-quienes__highlight" data-i18n-html="quienes_highlight">Descubre un nuevo nivel de alquiler de vehículos de alta gama en <strong>Motocar Rentals</strong>. ¡Bienvenido a la excelencia en movilidad!</p>
        </div>

        <div class="mc-quienes__feature">
            <div class="mc-quienes__feature-icon">
                <i class="fas fa-road"></i>
                <i class="fas fa-headset"></i>
            </div>
            <p data-i18n-html="quienes_feature">Nuestro servicio de alquiler incluye <strong>kilometraje ilimitado</strong> y <strong>asistencia en carretera las 24 horas</strong> del día, los 7 días de la semana. Esto significa que puede viajar sin preocupaciones por la distancia recorrida y contar con la tranquilidad de saber que estaremos disponibles para ayudarlo en cualquier momento durante su viaje.</p>
        </div>

        <div class="mc-quienes__mv">
            <div class="mc-quienes__mv-card">
                <div class="mc-quienes__mv-icon">
                    <i class="fas fa-bullseye"></i>
                </div>
                <h3 data-i18n="quienes_mision_title">Misión</h3>
                <p data-i18n="quienes_mision">Motocar Rentals es una compañía que facilita la movilidad de las personas, especialmente a la población antioqueña y a los turistas que visitan el país, ofreciendo servicios de renta de vehículos confiables y eficientes, respaldado por un equipo comprometido con la satisfacción y seguridad de sus usuarios, demostrados en la excelencia operativa y la atención personalizada.</p>
            </div>
            <div class="mc-quienes__mv-card">
                <div class="mc-quienes__mv-icon">
                    <i class="fas fa-eye"></i>
                </div>
                <h3 data-i18n="quienes_vision_title">Visión</h3>
                <p data-i18n="quienes_vision">Motocar Rentals será al 2028 la empresa líder en el sector de renta de vehículos en el Oriente Antioqueño, reconocida por la calidad de nuestros servicios, la diversidad de nuestra flota y la excelencia en la atención al cliente. Aspirando a contribuir con el desarrollo económico, turístico y social de la región, manteniendo altos estándares de sostenibilidad.</p>
            </div>
        </div>
    </div>
</section>

<!-- ==========================================
     MARCAS
     ========================================== -->
<section class="mc-brands">
    <div class="mc-container">
        <div class="mc-brands__grid">
            <div class="mc-brands__item">
                <img src="<?php echo get_template_directory_uri(); ?>/assets/img/brand-renault.png" alt="Renault">
            </div>
            <div class="mc-brands__item">
                <img src="<?php echo get_template_directory_uri(); ?>/assets/img/brand-kia.png" alt="KIA">
            </div>
            <div class="mc-brands__item">
                <img src="<?php echo get_template_directory_uri(); ?>/assets/img/brand-volkswagen.png" alt="Volkswagen">
            </div>
            <div class="mc-brands__item">
                <img src="<?php echo get_template_directory_uri(); ?>/assets/img/brand-yamaha.png" alt="Yamaha">
            </div>
            <div class="mc-brands__item">
                <img src="<?php echo get_template_directory_uri(); ?>/assets/img/brand-toyota.png" alt="Toyota">
            </div>
            <div class="mc-brands__item">
                <img src="<?php echo get_template_directory_uri(); ?>/assets/img/brand-suzuki.png" alt="Suzuki">
            </div>
        </div>
    </div>
</section>

<!-- ==========================================
     FOOTER
     ========================================== -->
<footer class="mc-footer">
    <div class="mc-container">
        <div class="mc-footer__grid">
            <div class="mc-footer__col">
                <div class="mc-footer__brand-row">
                    <div class="mc-footer__brand">
                        <img src="<?php echo get_template_directory_uri(); ?>/assets/img/logo-footer.png" alt="MotoCar Rentals">
                    </div>
                    <p class="mc-footer__tagline">Moto car Rentals</p>
                </div>
            </div>
            <div class="mc-footer__col">
                <h4 data-i18n="footer_servicios">Servicios 24/7</h4>
                <ul>
                    <li><i class="fas fa-phone"></i> +57 320 216 1156</li>
                    <li><i class="fas fa-envelope"></i> motocarrentals@gmail.com</li>
                </ul>
            </div>
            <div class="mc-footer__col">
                <h4 data-i18n="footer_contactanos">Contáctanos</h4>
                <div class="mc-footer__social">
                    <a href="https://www.facebook.com/p/MotoCar-Rentals-61558707917054/" target="_blank" aria-label="Facebook"><i class="fab fa-facebook-f"></i></a>
                    <a href="https://www.instagram.com/motocar_rentals/" target="_blank" aria-label="Instagram"><i class="fab fa-instagram"></i></a>
                    <a href="https://wa.me/573202161156" target="_blank" aria-label="WhatsApp"><i class="fab fa-whatsapp"></i></a>
                    <a href="https://www.tiktok.com/@motocar.rentals" target="_blank" aria-label="TikTok"><i class="fab fa-tiktok"></i></a>
                </div>
            </div>
            <div class="mc-footer__col">
                <h4 data-i18n="footer_contactar_title">¿Quieres que te contactemos?</h4>
                <form class="mc-footer__form">
                    <input type="email" placeholder="Tu correo electrónico" data-i18n-placeholder="footer_email_placeholder" required>
                    <button type="submit" class="mc-btn mc-btn--primary mc-btn--sm" data-i18n="footer_enviar">Enviar</button>
                </form>
            </div>
        </div>
        <div class="mc-footer__bottom">
            <p>&copy; <?php echo date('Y'); ?> MotoCar Rentals. <span data-i18n="footer_derechos">Todos los derechos reservados.</span></p>
        </div>
    </div>
</footer>

<!-- ==========================================
     MODAL DE DETALLE / RESERVA
     ========================================== -->
<div class="mc-modal" id="vehicleModal">
    <div class="mc-modal__overlay" onclick="closeVehicleModal()"></div>
    <div class="mc-modal__content">
        <button class="mc-modal__close" onclick="closeVehicleModal()" aria-label="Cerrar">
            <i class="fas fa-times"></i>
        </button>
        <div class="mc-modal__body">
            <div class="mc-modal__layout">
                <!-- Columna izquierda: vehículo -->
                <div class="mc-modal__left">
                    <h2 class="mc-modal__title" id="modalTitle">KIA SELTOS 2025</h2>

                    <div class="mc-modal__info-row">
                        <div class="mc-modal__image">
                            <img id="modalImage" src="" alt="Vehículo">
                        </div>
                        <div class="mc-modal__description">
                            <p id="modalDescripcion"></p>
                        </div>
                    </div>

                    <!-- Specs bar -->
                    <div class="mc-modal__specs-bar">
                        <button class="mc-modal__specs-arrow" id="specsLeft" aria-label="Anterior">
                            <i class="fas fa-chevron-left"></i>
                        </button>
                        <div class="mc-modal__specs-list">
                            <div class="mc-modal__spec-item">
                                <span class="mc-modal__spec-title" data-i18n="modal_motor">MOTOR</span>
                                <div class="mc-modal__spec-detail">
                                    <i class="fas fa-engine"></i>
                                    <span id="modalMotor">2000 CC</span>
                                </div>
                            </div>
                            <div class="mc-modal__spec-item">
                                <span class="mc-modal__spec-title" data-i18n="modal_abs">ABS</span>
                                <div class="mc-modal__spec-detail">
                                    <span class="mc-modal__spec-abs">(ABS)</span>
                                    <span id="modalABS">Sí</span>
                                </div>
                            </div>
                            <div class="mc-modal__spec-item">
                                <span class="mc-modal__spec-title" data-i18n="modal_pasajeros">PASAJEROS</span>
                                <div class="mc-modal__spec-detail">
                                    <i class="fas fa-users"></i>
                                    <span id="modalPasajeros">5</span>
                                </div>
                            </div>
                            <div class="mc-modal__spec-item">
                                <span class="mc-modal__spec-title" data-i18n="modal_tipo">TIPO</span>
                                <div class="mc-modal__spec-detail">
                                    <i class="fas fa-cog"></i>
                                    <span id="modalTransmision">Automática</span>
                                </div>
                            </div>
                        </div>
                        <button class="mc-modal__specs-arrow" id="specsRight" aria-label="Siguiente">
                            <i class="fas fa-chevron-right"></i>
                        </button>
                    </div>
                </div>

                <!-- Columna derecha: formulario cotización -->
                <div class="mc-modal__right">
                    <form class="mc-cotizar-form" id="reservationForm">
                        <input type="hidden" name="vehicle_name" id="reserveVehicleName">

                        <div class="mc-cotizar__field">
                            <label data-i18n="modal_fechas_label">Definir Fechas de renta</label>
                            <input type="text" id="modalFechas" placeholder="Seleccionar fechas" data-i18n-placeholder="modal_fechas_placeholder" readonly required>
                        </div>

                        <div class="mc-cotizar__field">
                            <label data-i18n="modal_entrega_label">Lugar de Entrega</label>
                            <input type="text" name="lugar_entrega" placeholder="Elegir Lugar..." data-i18n-placeholder="modal_entrega_placeholder">
                        </div>

                        <div class="mc-cotizar__field">
                            <label data-i18n="modal_devolucion_label">Lugar de Devolución</label>
                            <input type="text" name="lugar_devolucion" placeholder="Elegir Lugar..." data-i18n-placeholder="modal_devolucion_placeholder">
                        </div>

                        <div class="mc-cotizar__field">
                            <label data-i18n="modal_hora_entrega">Hora de Entrega</label>
                            <div class="mc-cotizar__time">
                                <input type="time" name="hora_entrega" value="11:10">
                            </div>
                        </div>

                        <div class="mc-cotizar__field">
                            <label data-i18n="modal_hora_devolucion">Hora de Devolución</label>
                            <div class="mc-cotizar__time">
                                <input type="time" name="hora_devolucion" value="11:10">
                            </div>
                        </div>

                        <button type="submit" class="mc-btn mc-btn--primary mc-btn--cotizar" data-i18n-html="modal_cotizar_btn">
                            Ir a Cotizar <i class="fab fa-whatsapp"></i>
                        </button>
                    </form>
                </div>
            </div>
        </div>
    </div>
</div>

<!-- WhatsApp Float Button -->
<a href="https://wa.me/573202161156?text=Hola%20MotoCar%20Rentals!%20Quiero%20información%20sobre%20alquiler%20de%20vehículos" class="mc-whatsapp-float" target="_blank" aria-label="WhatsApp">
    <i class="fab fa-whatsapp"></i>
</a>

<?php wp_footer(); ?>
</body>
</html>
